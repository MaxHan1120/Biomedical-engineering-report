% 本檔案用來分析 Biopac 設備測量的睜眼、閉眼時的 Delta, Theta, Alpha, Beta 頻譜
% 由於輸入為實數，因此 FFT 只取 Single-Sided Spectrum (正負頻率對稱)

clc; clear; close all; % 清理環境

Fs = 200; % 取樣頻率 (Hz)

% 讀取 Biopac 提供的 EEG 數據
biopac_open = readmatrix('biopac_data_open.xlsx');
biopac_close = readmatrix('biopac_data_close.xlsx');

% Biopac 數據第 2 到 5 行分別對應 Alpha, Beta, Delta, Theta
biopac_alpha_open = biopac_open(:, 2);
biopac_beta_open = biopac_open(:, 3);
biopac_delta_open = biopac_open(:, 4);
biopac_theta_open = biopac_open(:, 5);

biopac_alpha_close = biopac_close(:, 2);
biopac_beta_close = biopac_close(:, 3);
biopac_delta_close = biopac_close(:, 4);
biopac_theta_close = biopac_close(:, 5);

% 計算 FFT
N_open = length(biopac_alpha_open);
N_close = length(biopac_alpha_close);

f_biopac_open = (0:floor(N_open/2)) * (Fs / N_open);  % 睜眼頻率軸
f_biopac_close = (0:floor(N_close/2)) * (Fs / N_close); % 閉眼頻率軸

Y_biopac_delta_open = fft(biopac_delta_open);
Y_biopac_theta_open = fft(biopac_theta_open);
Y_biopac_alpha_open = fft(biopac_alpha_open);
Y_biopac_beta_open = fft(biopac_beta_open);

Y_biopac_delta_close = fft(biopac_delta_close);
Y_biopac_theta_close = fft(biopac_theta_close);
Y_biopac_alpha_close = fft(biopac_alpha_close);
Y_biopac_beta_close = fft(biopac_beta_close);

% 計算振幅 (單邊頻譜)
idx_open = 1:floor(N_open/2)+1;
idx_close = 1:floor(N_close/2)+1;

P1_biopac_delta_open = abs(Y_biopac_delta_open(idx_open)) / N_open;
P1_biopac_theta_open = abs(Y_biopac_theta_open(idx_open)) / N_open;
P1_biopac_alpha_open = abs(Y_biopac_alpha_open(idx_open)) / N_open;
P1_biopac_beta_open = abs(Y_biopac_beta_open(idx_open)) / N_open;

P1_biopac_delta_close = abs(Y_biopac_delta_close(idx_close)) / N_close;
P1_biopac_theta_close = abs(Y_biopac_theta_close(idx_close)) / N_close;
P1_biopac_alpha_close = abs(Y_biopac_alpha_close(idx_close)) / N_close;
P1_biopac_beta_close = abs(Y_biopac_beta_close(idx_close)) / N_close;

% 繪製比較圖 (Biopac 睜眼 vs. 閉眼)
figure;
sgtitle('Biopac 設備 - 睜眼 vs. 閉眼 FFT');

subplot(2,2,1);
idx_open_10Hz = f_biopac_open <= 10;
idx_close_10Hz = f_biopac_close <= 10;
plot(f_biopac_open(idx_open_10Hz), P1_biopac_delta_open(idx_open_10Hz), 'b', ...
     f_biopac_close(idx_close_10Hz), P1_biopac_delta_close(idx_close_10Hz), 'r');
title('Delta 波 (0.5 - 4 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('睜眼', '閉眼');
grid on; xlim([0 10]);

subplot(2,2,2);
idx_open_15Hz = f_biopac_open <= 15;
idx_close_15Hz = f_biopac_close <= 15;
plot(f_biopac_open(idx_open_15Hz), P1_biopac_theta_open(idx_open_15Hz), 'b', ...
     f_biopac_close(idx_close_15Hz), P1_biopac_theta_close(idx_close_15Hz), 'r');
title('Theta 波 (4 - 8 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('睜眼', '閉眼');
grid on; xlim([0 15]);

subplot(2,2,3);
idx_open_25Hz = f_biopac_open <= 25;
idx_close_25Hz = f_biopac_close <= 25;
plot(f_biopac_open(idx_open_25Hz), P1_biopac_alpha_open(idx_open_25Hz), 'b', ...
     f_biopac_close(idx_close_25Hz), P1_biopac_alpha_close(idx_close_25Hz), 'r');
title('Alpha 波 (8 - 13 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('睜眼', '閉眼');
grid on; xlim([0 25]);

subplot(2,2,4);
idx_open_50Hz = f_biopac_open <= 50;
idx_close_50Hz = f_biopac_close <= 50;
plot(f_biopac_open(idx_open_50Hz), P1_biopac_beta_open(idx_open_50Hz), 'b', ...
     f_biopac_close(idx_close_50Hz), P1_biopac_beta_close(idx_close_50Hz), 'r');
title('Beta 波 (13 - 30 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('睜眼', '閉眼');
grid on; xlim([0 50]);
