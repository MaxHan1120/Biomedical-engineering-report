% 本檔案用來分析睜眼、閉眼時Delta, Theta, Alpha, Beta頻譜的不同
% 由於我們的輸入為實數，因此底下進行fft時皆只取Single-Sided spectrum(因為正負會對稱)

clc; clear; close all; % 清理環境

Fs = 200; % 取樣頻率 (Hz)

% 讀取睜眼與閉眼 EEG 數據
data_open = readmatrix('open_eye_raw_data.xlsx');
data_close = readmatrix('close_eye_raw_data.xlsx');

EEG_open = data_open(:,1);  % 取得睜眼數據
EEG_close = data_close(:,1); % 取得閉眼數據

N = length(EEG_open); % 假設兩組數據長度相同
f = (0:floor(N/2)) * (Fs / N);  % 頻率軸 (單邊頻譜)

% 設計不同頻段的濾波器
delta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 0.5, 'HalfPowerFrequency2', 4, ...
    'SampleRate', Fs);

theta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 4, 'HalfPowerFrequency2', 8, ...
    'SampleRate', Fs);

alpha_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 8, 'HalfPowerFrequency2', 13, ...
    'SampleRate', Fs);

beta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 13, 'HalfPowerFrequency2', 30, ...
    'SampleRate', Fs);

% 濾波處理
delta_open = filter(delta_filt, EEG_open);
theta_open = filter(theta_filt, EEG_open);
alpha_open = filter(alpha_filt, EEG_open);
beta_open = filter(beta_filt, EEG_open);

delta_close = filter(delta_filt, EEG_close);
theta_close = filter(theta_filt, EEG_close);
alpha_close = filter(alpha_filt, EEG_close);
beta_close = filter(beta_filt, EEG_close);

% 計算 FFT
Y_delta_open = fft(delta_open);
Y_theta_open = fft(theta_open);
Y_alpha_open = fft(alpha_open);
Y_beta_open = fft(beta_open);

Y_delta_close = fft(delta_close);
Y_theta_close = fft(theta_close);
Y_alpha_close = fft(alpha_close);
Y_beta_close = fft(beta_close);

% 計算振幅
P1_delta_open = abs(Y_delta_open/N);
P1_theta_open = abs(Y_theta_open/N);
P1_alpha_open = abs(Y_alpha_open/N);
P1_beta_open = abs(Y_beta_open/N);

P1_delta_close = abs(Y_delta_close/N);
P1_theta_close = abs(Y_theta_close/N);
P1_alpha_close = abs(Y_alpha_close/N);
P1_beta_close = abs(Y_beta_close/N);

% 只取單邊頻譜
P1_delta_open = P1_delta_open(1:floor(N/2)+1);
P1_theta_open = P1_theta_open(1:floor(N/2)+1);
P1_alpha_open = P1_alpha_open(1:floor(N/2)+1);
P1_beta_open = P1_beta_open(1:floor(N/2)+1);

P1_delta_close = P1_delta_close(1:floor(N/2)+1);
P1_theta_close = P1_theta_close(1:floor(N/2)+1);
P1_alpha_close = P1_alpha_close(1:floor(N/2)+1);
P1_beta_close = P1_beta_close(1:floor(N/2)+1);

% 調整振幅 (因為我們只取單邊，所以乘 2)
P1_delta_open(2:end-1) = 2 * P1_delta_open(2:end-1);
P1_theta_open(2:end-1) = 2 * P1_theta_open(2:end-1);
P1_alpha_open(2:end-1) = 2 * P1_alpha_open(2:end-1);
P1_beta_open(2:end-1) = 2 * P1_beta_open(2:end-1);

P1_delta_close(2:end-1) = 2 * P1_delta_close(2:end-1);
P1_theta_close(2:end-1) = 2 * P1_theta_close(2:end-1);
P1_alpha_close(2:end-1) = 2 * P1_alpha_close(2:end-1);
P1_beta_close(2:end-1) = 2 * P1_beta_close(2:end-1);

% 畫圖比較睜眼與閉眼的頻譜

% 找出 0~50 Hz 的索引
idx = f <= 50;

% 畫圖比較睜眼與閉眼的頻譜
figure;

subplot(2,2,1);
plot(f(idx), P1_delta_open(idx), 'b', f(idx), P1_delta_close(idx), 'r');
title('Delta 波頻譜 (0.5 - 4 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 10]); % 限制 X 軸範圍

subplot(2,2,2);
plot(f(idx), P1_theta_open(idx), 'b', f(idx), P1_theta_close(idx), 'r');
title('Theta 波頻譜 (4 - 8 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 15]);

subplot(2,2,3);
plot(f(idx), P1_alpha_open(idx), 'b', f(idx), P1_alpha_close(idx), 'r');
title('Alpha 波頻譜 (8 - 13 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 25]);

subplot(2,2,4);
plot(f(idx), P1_beta_open(idx), 'b', f(idx), P1_beta_close(idx), 'r');
title('Beta 波頻譜 (13 - 30 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 50]);


% 分四張圖畫
% 找出 0~50 Hz 的索引
idx = f <= 50; 

% 繪製 Delta 波頻譜 (0.5 - 4 Hz)
figure;
plot(f(idx), P1_delta_open(idx), 'b', f(idx), P1_delta_close(idx), 'r');
title('Delta 波頻譜 (0.5 - 4 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 10]); % 限制 X 軸範圍到 50 Hz

% 繪製 Theta 波頻譜 (4 - 8 Hz)
figure;
plot(f(idx), P1_theta_open(idx), 'b', f(idx), P1_theta_close(idx), 'r');
title('Theta 波頻譜 (4 - 8 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 15]); 

% 繪製 Alpha 波頻譜 (8 - 13 Hz)
figure;
plot(f(idx), P1_alpha_open(idx), 'b', f(idx), P1_alpha_close(idx), 'r');
title('Alpha 波頻譜 (8 - 13 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 25]); 

% 繪製 Beta 波頻譜 (13 - 30 Hz)
figure;
plot(f(idx), P1_beta_open(idx), 'b', f(idx), P1_beta_close(idx), 'r');
title('Beta 波頻譜 (13 - 30 Hz)');
xlabel('頻率 (Hz)');
ylabel('振幅');
legend('睜眼', '閉眼');
grid on;
xlim([0 50]); 

