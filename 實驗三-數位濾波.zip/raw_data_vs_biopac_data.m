% 本檔案用來分析raw_data經過濾波後得到的波型，與biopac計算得到的波型的差異性
% 由於輸入為實數，進行 FFT 時皆只取 Single-Sided Spectrum

clc; clear; close all; % 清理環境

Fs = 200; % 取樣頻率 (Hz)

% 讀取睜眼與閉眼 EEG 原始數據
data_open = readmatrix('open_eye_raw_data.xlsx');
data_close = readmatrix('close_eye_raw_data.xlsx');

EEG_open = data_open(:,1);  % 取得睜眼數據
EEG_close = data_close(:,1); % 取得閉眼數據

N = length(EEG_open); % 睜眼樣本數
M = length(EEG_close); % 閉眼樣本數

f_open = (0:floor(N/2)) * (Fs / N);  % 睜眼頻率軸
f_close = (0:floor(M/2)) * (Fs / M); % 閉眼頻率軸

% 讀取 Biopac 儀器的時域數據
biopac_open = readmatrix('biopac_data_open.xlsx');
biopac_close = readmatrix('biopac_data_close.xlsx');

% Biopac 數據第 2 到 5 行分別對應 Alpha, Beta, Delta, Theta
biopac_alpha_open = biopac_open(:, 2);
biopac_beta_open = biopac_open(:, 3);
biopac_delta_open = biopac_open(:, 4);
biopac_theta_open = biopac_open(:, 5);

biopac_alpha_close = biopac_close(:, 2);
biopac_beta_close = biopac_close(:, 3);
biopac_delta_close = biopac_close(:, 4);
biopac_theta_close = biopac_close(:, 5);

% 設計不同頻段的濾波器
delta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 0.5, 'HalfPowerFrequency2', 4, ...
    'SampleRate', Fs);

theta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 4, 'HalfPowerFrequency2', 8, ...
    'SampleRate', Fs);

alpha_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 8, 'HalfPowerFrequency2', 13, ...
    'SampleRate', Fs);

beta_filt = designfilt('bandpassiir', 'FilterOrder', 6, ...
    'HalfPowerFrequency1', 13, 'HalfPowerFrequency2', 30, ...
    'SampleRate', Fs);

% 濾波處理
delta_open = filter(delta_filt, EEG_open);
theta_open = filter(theta_filt, EEG_open);
alpha_open = filter(alpha_filt, EEG_open);
beta_open = filter(beta_filt, EEG_open);

delta_close = filter(delta_filt, EEG_close);
theta_close = filter(theta_filt, EEG_close);
alpha_close = filter(alpha_filt, EEG_close);
beta_close = filter(beta_filt, EEG_close);

% 計算 FFT (我們的濾波後數據)
Y_delta_open = fft(delta_open);
Y_theta_open = fft(theta_open);
Y_alpha_open = fft(alpha_open);
Y_beta_open = fft(beta_open);

Y_delta_close = fft(delta_close);
Y_theta_close = fft(theta_close);
Y_alpha_close = fft(alpha_close);
Y_beta_close = fft(beta_close);

% 計算 FFT (Biopac 提供的數據)
Y_biopac_delta_open = fft(biopac_delta_open);
Y_biopac_theta_open = fft(biopac_theta_open);
Y_biopac_alpha_open = fft(biopac_alpha_open);
Y_biopac_beta_open = fft(biopac_beta_open);

Y_biopac_delta_close = fft(biopac_delta_close);
Y_biopac_theta_close = fft(biopac_theta_close);
Y_biopac_alpha_close = fft(biopac_alpha_close);
Y_biopac_beta_close = fft(biopac_beta_close);

% 計算振幅 (只取單邊頻譜)
idx_open = 1:floor(N/2)+1;
idx_close = 1:floor(M/2)+1;

P1_delta_open = abs(Y_delta_open(idx_open))/N;
P1_theta_open = abs(Y_theta_open(idx_open))/N;
P1_alpha_open = abs(Y_alpha_open(idx_open))/N;
P1_beta_open = abs(Y_beta_open(idx_open))/N;

P1_biopac_delta_open = abs(Y_biopac_delta_open(idx_open))/N;
P1_biopac_theta_open = abs(Y_biopac_theta_open(idx_open))/N;
P1_biopac_alpha_open = abs(Y_biopac_alpha_open(idx_open))/N;
P1_biopac_beta_open = abs(Y_biopac_beta_open(idx_open))/N;

P1_delta_close = abs(Y_delta_close(idx_close))/M;
P1_theta_close = abs(Y_theta_close(idx_close))/M;
P1_alpha_close = abs(Y_alpha_close(idx_close))/M;
P1_beta_close = abs(Y_beta_close(idx_close))/M;

P1_biopac_delta_close = abs(Y_biopac_delta_close(idx_close))/M;
P1_biopac_theta_close = abs(Y_biopac_theta_close(idx_close))/M;
P1_biopac_alpha_close = abs(Y_biopac_alpha_close(idx_close))/M;
P1_biopac_beta_close = abs(Y_biopac_beta_close(idx_close))/M;

% 繪製比較圖 (睜眼 FFT 計算 vs. Biopac FFT 結果)
figure;
sgtitle('睜眼狀態 (Open Eyes) - FFT 計算 vs. Biopac FFT');

subplot(2,2,1);
idx_open_10Hz = f_open <= 10;
plot(f_open(idx_open_10Hz), P1_delta_open(idx_open_10Hz), 'b', ...
     f_open(idx_open_10Hz), P1_biopac_delta_open(idx_open_10Hz), 'r');
title('Delta 波 (0.5 - 4 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 10]);

subplot(2,2,2);
idx_open_15Hz = f_open <= 15;
plot(f_open(idx_open_15Hz), P1_theta_open(idx_open_15Hz), 'b', ...
     f_open(idx_open_15Hz), P1_biopac_theta_open(idx_open_15Hz), 'r');
title('Theta 波 (4 - 8 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 15]);

subplot(2,2,3);
idx_open_25Hz = f_open <= 25;
plot(f_open(idx_open_25Hz), P1_alpha_open(idx_open_25Hz), 'b', ...
     f_open(idx_open_25Hz), P1_biopac_alpha_open(idx_open_25Hz), 'r');
title('Alpha 波 (8 - 13 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 25]);

subplot(2,2,4);
idx_open_50Hz = f_open <= 50;
plot(f_open(idx_open_50Hz), P1_beta_open(idx_open_50Hz), 'b', ...
     f_open(idx_open_50Hz), P1_biopac_beta_open(idx_open_50Hz), 'r');
title('Beta 波 (13 - 30 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 50]);


% 繪製比較圖 (閉眼 FFT 計算 vs. Biopac FFT 結果)
figure;
sgtitle('閉眼狀態 (Closed Eyes) - FFT 計算 vs. Biopac FFT');

subplot(2,2,1);
idx_close_10Hz = f_close <= 10;
plot(f_close(idx_close_10Hz), P1_delta_close(idx_close_10Hz), 'b', ...
     f_close(idx_close_10Hz), P1_biopac_delta_close(idx_close_10Hz), 'r');
title('Delta 波 (0.5 - 4 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 10]);

subplot(2,2,2);
idx_close_15Hz = f_close <= 15;
plot(f_close(idx_close_15Hz), P1_theta_close(idx_close_15Hz), 'b', ...
     f_close(idx_close_15Hz), P1_biopac_theta_close(idx_close_15Hz), 'r');
title('Theta 波 (4 - 8 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 15]);

subplot(2,2,3);
idx_close_25Hz = f_close <= 25;
plot(f_close(idx_close_25Hz), P1_alpha_close(idx_close_25Hz), 'b', ...
     f_close(idx_close_25Hz), P1_biopac_alpha_close(idx_close_25Hz), 'r');
title('Alpha 波 (8 - 13 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 25]);

subplot(2,2,4);
idx_close_50Hz = f_close <= 50;
plot(f_close(idx_close_50Hz), P1_beta_close(idx_close_50Hz), 'b', ...
     f_close(idx_close_50Hz), P1_biopac_beta_close(idx_close_50Hz), 'r');
title('Beta 波 (13 - 30 Hz)');
xlabel('頻率 (Hz)'); ylabel('振幅');
legend('FFT 計算', 'Biopac FFT');
grid on; xlim([0 50]);
